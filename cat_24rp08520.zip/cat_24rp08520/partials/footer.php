</div>
<footer class="bg-light border-top py-3 mt-5">
  <div class="container d-flex justify-content-between small">
    <div>© <?php echo date('Y'); ?> RP Karongi Library</div>
    <div>Email: library@rpkarongi.ac.rw • Tel: +250 000 000</div>
  </div>
</footer>
<script src="/cat_24rp08520/bootstrap-5.3.8-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
