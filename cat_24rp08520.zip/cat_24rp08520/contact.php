<?php include __DIR__.'/partials/header.php'; ?>
<h3>Contact</h3>
<p>Address: RP Karongi, Rwanda</p>
<p>Email: library@rpkarongi.ac.rw</p>
<?php include __DIR__.'/partials/footer.php'; ?>
